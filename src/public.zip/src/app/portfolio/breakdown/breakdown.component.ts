import { Component, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts';
import { HighchartsChartModule } from 'highcharts-angular';
import holding from 'C:/workspace/datas/holdings.json';
import moment from 'moment';
import current from 'C:/workspace/datas/total-trade.json';

import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';

export interface UserData {
  symbol: string;
  buy_quantity: Number;
  buy_price: Number;
  // current_price: string;
  // change: string;
  // pchange: Number;
}
@Component({
  selector: 'app-breakdown',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    HighchartsChartModule,
    MatSelectModule,
  ],
  templateUrl: './breakdown.component.html',
  styleUrl: './breakdown.component.scss',
})
export class BreakdownComponent {
  Highcharts: typeof Highcharts = Highcharts;
  categories = [];
  //Highcharts.Options
  displayedColumns: string[] = [
    'symbol',
    'buy_price',
    'buy_quantity',
    // 'current_price',
    // 'pchange',
    // 'change',
    // 'todaysPL',
    // 'current_return',
    'action',
  ];
  months = [];
  monthlyBuy = [];
  dataSource: MatTableDataSource<UserData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  chartOptions: any = {
    // series: [
    //   {
    //     name: 'Label',
    //     data: [1, 2, 3],
    //     type: 'line',
    //   },
    // ],
    chart: {
      type: 'bar',
    },
    title: {
      text: 'Holding',
      align: 'left',
    },
    accessibility: {
      point: {
        valueDescriptionFormat: '{index}. Age {xDescription}, {value}%.',
      },
    },
    xAxis: [
      {
        categories: this.categories,
        reversed: false,
        labels: {
          step: 1,
        },
        accessibility: {
          description: 'Age (male)',
        },
      },
      {
        // mirror axis on right side
        opposite: true,
        reversed: false,
        categories: this.categories,
        linkedTo: 0,
        labels: {
          step: 1,
        },
        accessibility: {
          description: 'Age (female) (value)',
        },
      },
    ],
    yAxis: {
      title: {
        text: null,
      },

      accessibility: {
        description: 'Percentage population',
        rangeDescription: 'Range: 0 to 5%',
      },
    },

    plotOptions: {
      series: {
        stacking: 'normal',
      },
    },

    tooltip: {
      format:
        '<b>{series.name}, age {point.category}</b><br/>' + 'Population: {x}%',
    },

    series: [
      {
        name: 'Male',
        data: [
          0, -2.09, -2.45, -2.71, -2.97, -3.69, -4.04, -3.81, -4.19, -4.61,
          -4.56, -4.21, -3.53, -2.55, -1.82, -1.46, -0.78, -0.71,
        ],
        type: 'bar',
      },
      {
        name: 'Female',
        data: [
          1.35, 1.98, 2.43, 2.39, 2.71, 3.02, 3.5, 3.52, 4.03, 4.4, 4.17, 3.88,
          3.29, 2.42, 1.8, 1.39, 0.99, 1.15,
        ],
        type: 'bar',
      },
    ],
  };

  constructor() {
    console.log(holding);
    let monthlyBuy = [];
    let currentMonth = 0;
    holding.map((item) => {
      //moment(new Date(endDate)).diff(new Date(startDate), 'months', true);
      // console.log(item);
      const someDate = new Date();
      const enddate = [someDate.getFullYear(), someDate.getMonth() + 1, 1];
      const startdate = moment(
        new Date(item.buy_date).getFullYear() +
          '-' +
          (new Date(item.buy_date).getMonth() + 1) +
          '-' +
          '01'
      ).format('YYYY-MM-DD'); //moment().format('mm-yyyy')
      // console.log(enddate);
      // console.log(new Date(startdate));

      let totalmonth = parseInt(
        moment(enddate).diff(new Date(startdate), 'months', true).toFixed()
      );

      if (currentMonth != totalmonth) {
        monthlyBuy.push({
          monthNmber: totalmonth,
          buy_date: item.buy_date,
          invested_amount: 0,
          current_value: 0,
          per: 0,
          stocks: [],
        });
      }
      currentMonth = totalmonth;

      const lastIndex = monthlyBuy.length - 1;

      monthlyBuy[lastIndex].invested_amount +=
        item.buy_price * item.buy_quantity;

      monthlyBuy[lastIndex].current_value +=
        current.total.data.filter((t) => t.symbol == item.symbol)[0].lastPrice *
        item.buy_quantity;
      monthlyBuy[lastIndex].stocks.push({ ...item });
    });

    monthlyBuy.map((item) => {
      item.current_value = parseFloat(item.current_value.toFixed(2));
      item.invested_amount = parseFloat(item.invested_amount.toFixed(2));
      item.buy_date = moment(item.buy_date).format('MMM-YYYY');
    });

    console.log(monthlyBuy);

    this.initPlot(monthlyBuy);
    this.months = monthlyBuy.map((item) => item.buy_date);
    this.monthlyBuy = monthlyBuy;
    this.initTable('');
  }

  initPlot(monthlyBuy) {
    const category = [];
    const current_value = [];
    const invested_amount = [];
    const profit = [];

    monthlyBuy.map((item) => {
      category.push(item.buy_date);
      current_value.push(item.current_value);
      invested_amount.push(item.invested_amount);
      profit.push(item.current_value - item.invested_amount);
    });
    this.chartOptions = {
      chart: {
        type: 'column',
      },
      title: {
        text: 'Column chart with negative values',
      },
      xAxis: {
        categories: category,
      },
      credits: {
        enabled: false,
      },
      plotOptions: {
        column: {
          borderRadius: '25%',
        },
        series: {
          events: {
            click: (event) => {
              this.clickBars(event);
            },
          },
        },
      },

      series: [
        {
          name: 'Invested',
          data: invested_amount,
        },
        {
          name: 'Current',
          data: current_value,
        },
        {
          name: 'Profit',
          data: profit,
        },
      ],
    };

    // this.chartOptions.update({
    //   plotOptions: {
    //     series: {
    //       events: {
    //         click: (event) => {
    //           alert('you clicked something');
    //         },
    //       },
    //     },
    //   },
    // });
  }
  clickBars(details) {
    console.log(details);
  }
  initTable(month) {
    if (!month) {
      month = this.months.reverse()[0];
    }

    const data: any = this.monthlyBuy.filter(
      (item) => item.buy_date == month
    )[0];
    this.dataSource = new MatTableDataSource(data.stocks);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    console.log(data);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
