import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
// import { environment } from '../../../environments/environment';

import data from 'C:/workspace/datas/holdings.json';
import current from 'C:/workspace/datas/total-trade.json';

export interface UserData {
  symbol: string;
  quantity: Number;
  price: Number;
  current_price: string;
  change: string;
  pchange: Number;
}

@Component({
  selector: 'app-holdings',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
  ],
  templateUrl: './holdings.component.html',
  styleUrl: './holdings.component.scss',
})
export class HoldingsComponent {
  displayedColumns: string[] = [
    'symbol',
    'price',
    'quantity',
    'current_price',
    'pchange',
    'change',
    'todaysPL',
    'current_return',
    'action',
  ];
  dataSource: MatTableDataSource<UserData>;

  holdings = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  todaysPL = 0;
  constructor() {
    // Create 100 users

    // Assign the data to the data source for the table to render

    const roundOff = (data) => {
      return parseFloat(data.toFixed(2));
    };

    data.map((item) => {
      const key = this.holdings.findIndex((tmp) => tmp.symbol == item.symbol);
      this.holdings.filter((tmp) => tmp.symbol == item.symbol);
      if (key == -1) {
        this.holdings.push({
          symbol: item.symbol,
          quantity: item.buy_quantity,
          price: item.buy_price,
          total_trade: 1,
          invested_amount: roundOff(item.buy_quantity * item.buy_price),
        });
      } else {
        // debugger;
        // console.log(this.holdings);
        // let price = this.holdings[key].price + item.buy_price
        let t = {
          symbol: item.symbol,
          quantity: this.holdings[key].quantity + item.buy_quantity,
          total_trade: this.holdings[key].total_trade + 1,
          price: item.buy_price,
          invested_amount: roundOff(
            this.holdings[key].invested_amount +
              item.buy_quantity * item.buy_price
          ),
        };

        t.price = roundOff(t.invested_amount / t.quantity);
        this.holdings[key] = t;
      }
    });
    let post = 0;
    let neg = 0;
    let priceNotSetStocks = [];
    this.holdings.map((item) => {
      const tmpCurrent = current.total.data.filter(
        (s) => s.symbol == item.symbol
      )[0];
      if (tmpCurrent == undefined) {
        priceNotSetStocks.push(item.symbol);
        return;
      }

      item.current_price = tmpCurrent.lastPrice;
      item.pchange = roundOff(tmpCurrent.pchange);
      item.change = roundOff(tmpCurrent.change);
      item.todaysPL = roundOff(tmpCurrent.change * item.quantity);
      item.current_return = roundOff(
        (item.current_price - item.price) * item.quantity
      ).toFixed();
      if (tmpCurrent.pchange >= 0) {
        // console.log('POST', item.symbol, post);
        post += item.change * item.quantity;
      } else {
        // console.log('Neg', item.symbol, neg);
        neg -= item.change * item.quantity;
      }
    });
    console.log(priceNotSetStocks);
    this.todaysPL = post - neg;
    // console.log(this.holdings);
    this.dataSource = new MatTableDataSource(this.holdings);
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
