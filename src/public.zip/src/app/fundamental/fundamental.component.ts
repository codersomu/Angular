import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { DataService } from '../_services/data.service';

import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-fundamental',
  standalone: true,
  imports: [
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
  ],
  templateUrl: './fundamental.component.html',
  styleUrl: './fundamental.component.scss',
})
export class FundamentalComponent {
  holdings = this._data.getHoldings();
  allHoldingStocks = this._data.allHoldingStocks();

  displayedColumns: string[] = [
    'script',

    //  'all_linked_indices',
    'Sector',
    'Industry',
    'PE',
    'roce',
    'roe',
    'dividend_yield',
    'pandl',
    'compounded_profit_growth',
    'compounded_sales_growth',
    'return_on_equity',
    'screener_company_id',
  ];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _data: DataService) {
    this._data.getMain().subscribe((data: any) => {
      this._data.company = data;
      console.log(this.allHoldingStocks);
      let companys = [];
      // this.allHoldingStocks.map((item) => {
      //   const t = this._data.getCompanyInfoByName(item);
      //   try {
      //     if ('all_linked_indices' in t && t.all_linked_indices.length) {
      //       if (1 && t.Sector == 'Alcoholic Beverages') {
      //         t.pandl.reverse();
      //         companys.push(t);
      //       }
      //     }
      //   } catch (error) {
      //     console.log('no data', item);
      //   }
      // });
      // const d = this._data.getCompanyInfoByName('RELIANCE');

      data.map((item) => {
        item.pandl.reverse();
        try {
          if (
            'opm_' in item.pandl[0] &&
            item.pandl[0]?.opm_ > 30 &&
            // item.PE < 100 &&
            item.roce > 20
          ) {
            companys.push(item);
          }
        } catch (error) {}

        // if (1 && item.Sector == 'Alcoholic Beverages') {
        //   companys.push(item);
        // }
      });

      console.log(companys);

      this.dataSource = new MatTableDataSource(companys);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  ngAfterViewInit() {
    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
