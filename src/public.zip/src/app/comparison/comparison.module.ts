import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComparisonRoutingModule } from './comparison-routing.module';

import * as more from 'highcharts/highcharts-more.src';
import * as exporting from 'highcharts/modules/exporting.src';

@NgModule({
  declarations: [],
  imports: [CommonModule, ComparisonRoutingModule],
})
export class ComparisonModule {}
