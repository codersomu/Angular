import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HoldingComponent } from './holding/holding.component';
import { IntradayComponent } from './intraday/intraday.component';

const routes: Routes = [
  { path: '', component: IntradayComponent },
  { path: 'holding', component: HoldingComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ComparisonRoutingModule {}
