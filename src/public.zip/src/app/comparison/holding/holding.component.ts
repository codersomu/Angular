import { Component } from '@angular/core';
//  import { Chart } from 'angular-highcharts';

import * as Highcharts from 'highcharts';
import { HighchartsChartModule } from 'highcharts-angular';
import holding from 'C:/workspace/datas/holdings.json';
import current from 'C:/workspace/datas/total-trade.json';
import { interval } from 'rxjs';
import moment from 'moment';
@Component({
  selector: 'app-holding',
  standalone: true,
  imports: [HighchartsChartModule],
  templateUrl: './holding.component.html',
  styleUrl: './holding.component.scss',
})
export class HoldingComponent {
  // chart: Chart;

  Highcharts: typeof Highcharts = Highcharts;
  holdings = [];
  categories = [];

  totalPos = 0;
  totalNeg = 0;

  chartOptions: Highcharts.Options = {
    // series: [
    //   {
    //     name: 'Label',
    //     data: [1, 2, 3],
    //     type: 'line',
    //   },
    // ],
    chart: {
      type: 'bar',
    },
    title: {
      text: 'Holding',
      align: 'left',
    },
    accessibility: {
      point: {
        valueDescriptionFormat: '{index}. Age {xDescription}, {value}%.',
      },
    },
    xAxis: [
      {
        categories: this.categories,
        reversed: false,
        labels: {
          step: 1,
        },
        accessibility: {
          description: 'Age (male)',
        },
      },
      {
        // mirror axis on right side
        opposite: true,
        reversed: false,
        categories: this.categories,
        linkedTo: 0,
        labels: {
          step: 1,
        },
        accessibility: {
          description: 'Age (female) (value)',
        },
      },
    ],
    yAxis: {
      title: {
        text: null,
      },

      accessibility: {
        description: 'Percentage population',
        rangeDescription: 'Range: 0 to 5%',
      },
    },

    plotOptions: {
      series: {
        stacking: 'normal',
      },
    },

    tooltip: {
      format:
        '<b>{series.name}, age {point.category}</b><br/>' + 'Population: {x}%',
    },

    series: [
      {
        name: 'Male',
        data: [
          0, -2.09, -2.45, -2.71, -2.97, -3.69, -4.04, -3.81, -4.19, -4.61,
          -4.56, -4.21, -3.53, -2.55, -1.82, -1.46, -0.78, -0.71,
        ],
        type: 'bar',
      },
      {
        name: 'Female',
        data: [
          1.35, 1.98, 2.43, 2.39, 2.71, 3.02, 3.5, 3.52, 4.03, 4.4, 4.17, 3.88,
          3.29, 2.42, 1.8, 1.39, 0.99, 1.15,
        ],
        type: 'bar',
      },
    ],
  };

  //ngOnInit() {}

  constructor() {
    // Create 100 users

    // const data = holding;

    // Assign the data to the data source for the table to render
    const from = moment('2024-01-01');
    const data = [];

    holding.filter((item) => {
      if (moment(item.buy_date).diff(from) >= 0) {
        data.push(item);
      }
    });

    // debugger;

    const roundOff = (data) => {
      return parseFloat(data.toFixed(2));
    };

    data.map((item) => {
      const key = this.holdings.findIndex((tmp) => tmp.symbol == item.symbol);
      this.holdings.filter((tmp) => tmp.symbol == item.symbol);
      if (key == -1) {
        this.holdings.push({
          symbol: item.symbol,
          quantity: item.buy_quantity,
          price: item.buy_price,
          total_trade: 1,
          invested_amount: roundOff(item.buy_quantity * item.buy_price),
        });
      } else {
        // debugger;
        // console.log(this.holdings);
        // let price = this.holdings[key].price + item.buy_price
        let t = {
          symbol: item.symbol,
          quantity: this.holdings[key].quantity + item.buy_quantity,
          total_trade: this.holdings[key].total_trade + 1,
          price: item.buy_price,
          invested_amount: roundOff(
            this.holdings[key].invested_amount +
              item.buy_quantity * item.buy_price
          ),
        };

        t.price = roundOff(t.invested_amount / t.quantity);
        this.holdings[key] = t;
      }
    });
    let post = 0;
    let neg = 0;
    let priceNotSetStocks = [];

    this.holdings.map((item) => {
      const tmpCurrent = current.total.data.filter(
        (s) => s.symbol == item.symbol
      )[0];

      if (tmpCurrent == undefined) {
        priceNotSetStocks.push(item.symbol);
        return;
      }
      item.current_price = tmpCurrent.lastPrice;
      item.pchange = roundOff(tmpCurrent.pchange);
      item.change = roundOff(tmpCurrent.change);
      item.todaysPL = roundOff(tmpCurrent.change * item.quantity);
      item.current_return = roundOff(
        (item.current_price - item.price) * item.quantity
      ).toFixed();

      item.perPL = this.getPercentage(item.current_price, item.price);
    });

    console.log(priceNotSetStocks);

    // this.dataSource = new MatTableDataSource(this.holdings);

    let stocks = this.holdings.map((item) => item.symbol);
    stocks = [...new Set(stocks)].sort();
    console.log(stocks);

    let postive = [];
    let negetive = [];

    stocks.map((item) => {
      const tmpCurrent = this.holdings.filter((s) => s.symbol == item)[0];
      if (tmpCurrent.perPL >= 0) {
        this.totalPos += 1;
        postive.push(tmpCurrent.perPL);
        negetive.push(0);
      } else {
        this.totalNeg += 1;
        negetive.push(tmpCurrent.perPL);
        postive.push(0);
      }
    });

    this.init(stocks, postive, negetive);

    // stocks.map((item, index) => {
    //   console.log(item, postive[index], negetive[index]);
    // });
  }

  getPercentage(initalval, finalVal) {
    return ((initalval - finalVal) / ((initalval + finalVal) / 2)) * 100;
  }

  init(data, pos, neg) {
    this.chartOptions = {
      // series: [
      //   {
      //     name: 'Label',
      //     data: [1, 2, 3],
      //     type: 'line',
      //   },
      // ],
      chart: {
        type: 'bar',
      },
      title: {
        text: 'Holding',
        align: 'left',
      },
      accessibility: {
        point: {
          valueDescriptionFormat: '{index}. Age {xDescription}, {value}%.',
        },
      },
      xAxis: [
        {
          categories: data,
          reversed: false,
          labels: {
            step: 1,
          },
          accessibility: {
            description: '(male)- {value} ',
          },
        },
        {
          // mirror axis on right side
          opposite: true,
          reversed: false,
          categories: data,
          linkedTo: 0,
          labels: {
            step: 1,
          },
          accessibility: {
            description: '(female)',
          },
        },
      ],
      yAxis: {
        title: {
          text: null,
        },

        accessibility: {
          description: 'Percentage population',
          rangeDescription: 'Range: 0 to 5%',
        },
      },

      plotOptions: {
        series: {
          stacking: 'normal',
        },
      },

      tooltip: {
        format: '<b>{series.name}, {point.category}</b><br/>' + 'Per: {y}%',
      },

      series: [
        {
          name: 'Pos',
          data: pos,
          type: 'bar',
        },
        {
          name: 'Neg',
          data: neg,
          type: 'bar',
        },
      ],
    };
  }
}
