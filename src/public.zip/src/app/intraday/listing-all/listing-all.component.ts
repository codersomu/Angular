import { AfterViewInit, Component, ViewChild } from '@angular/core';

import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';

import current from 'C:/workspace/datas/total-trade.json';

@Component({
  selector: 'app-listing-all',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
  ],
  templateUrl: './listing-all.component.html',
  styleUrl: './listing-all.component.scss',
})
export class ListingAllComponent {
  displayedColumns: string[] = [
    'rank',
    'symbol',
    'series',
    'pchange',
    'change',
    'lastPrice',
    'action',
  ];
  dataSource: MatTableDataSource<any>;
  companys: any = current.total.data.filter((item) => item.series == 'EQ');
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor() {
    this.companys.map((item, index) => {
      item.rank = index;
    });
    this.dataSource = new MatTableDataSource(this.companys);
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
