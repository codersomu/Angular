import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListingAllComponent } from './listing-all.component';

describe('ListingAllComponent', () => {
  let component: ListingAllComponent;
  let fixture: ComponentFixture<ListingAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListingAllComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListingAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
