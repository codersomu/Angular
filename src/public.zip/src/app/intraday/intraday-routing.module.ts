import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListingAllComponent } from './listing-all/listing-all.component';

const routes: Routes = [{ path: '', component: ListingAllComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IntradayRoutingModule {}
