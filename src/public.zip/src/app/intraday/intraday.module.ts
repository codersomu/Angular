import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IntradayRoutingModule } from './intraday-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    IntradayRoutingModule
  ]
})
export class IntradayModule { }
