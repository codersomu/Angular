import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TradesRoutingModule } from './trades-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TradesRoutingModule
  ]
})
export class TradesModule { }
