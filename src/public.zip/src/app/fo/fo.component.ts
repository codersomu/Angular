import { Component } from '@angular/core';
import * as Highcharts from 'highcharts';
import { HighchartsChartModule } from 'highcharts-angular';
import { DataService } from '../_services/data.service';

@Component({
  selector: 'app-fo',
  standalone: true,
  imports: [HighchartsChartModule],
  templateUrl: './fo.component.html',
  styleUrl: './fo.component.scss',
})
export class FoComponent {
  Highcharts: typeof Highcharts = Highcharts;
  // Highcharts.Options
  chartOptions: any = {
    chart: {
      type: 'column',
    },
    title: {
      text: 'Corn vs wheat estimated production for 2023',
    },
    subtitle: {
      text:
        'Source: <a target="_blank" ' +
        'href="https://www.indexmundi.com/agriculture/?commodity=corn">indexmundi</a>',
    },
    xAxis: {
      categories: ['USA', 'China', 'Brazil', 'EU', 'Argentina', 'India'],
      crosshair: true,
      accessibility: {
        description: 'Countries',
      },
    },
    yAxis: {
      min: 0,
      title: {
        text: '1000 metric tons (MT)',
      },
    },
    tooltip: {
      valueSuffix: ' (1000 MT)',
    },
    plotOptions: {
      column: {
        pointPadding: 0.2,
        borderWidth: 0,
      },
    },
    series: [
      {
        name: 'Corn',
        data: [387749, 280000, 129000, 64300, 54000, 34300],
      },
      {
        name: 'Wheat',
        data: [45321, 140000, 10000, 140500, 19500, 113500],
      },
    ],
  };

  constructor(private _data: DataService) {
    this._data.getFoDetails('RELIANCE').subscribe((data: any) => {
      console.log(data);

      const price = data.data[0].ce[0].SttlmPric;
      // let allStrike = [];
      let allStrike = [
        ...new Set([
          ...data.data[0].ce.map((item) => item.OptnTp),
          ...data.data[0].pe.map((item) => item.OptnTp),
        ]),
      ].sort();

      const ln = allStrike.length / 2;
      allStrike = [
        ...allStrike.slice(ln - 10, ln),
        ...allStrike.slice(ln, ln + 10),
      ];

      let allPE = [];
      let allCE = [];
      allStrike.map((item, index) => {
        let t_ce = '0';
        let t_pe = '0';

        // 1210 - 1320
        try {
          t_ce = data.data[0].ce.filter((t_item) => t_item.OptnTp == item)[0]
            .ChngInOpnIntrst;
        } catch (error) {
          console.log(error);
        }

        try {
          t_pe = data.data[0].pe.filter((t_item) => t_item.OptnTp == item)[0]
            .ChngInOpnIntrst;
        } catch (error) {}

        allPE.push(parseFloat(t_ce));
        allCE.push(parseFloat(t_pe));
      });

      console.log(allStrike, allPE, allCE);

      this.chartOptions = {
        chart: {
          type: 'column',
        },
        title: {
          text: 'PE vs CE estimated production for RELIANCE - ' + price,
        },
        subtitle: {
          text:
            'Source: <a target="_blank" ' +
            'href="https://www.indexmundi.com/agriculture/?commodity=corn">indexmundi</a>',
        },
        xAxis: {
          categories: allStrike,
          crosshair: true,
          accessibility: {
            description: 'Countries',
          },
        },
        yAxis: {
          min: 0,
          title: {
            text: '1000 metric tons (MT)',
          },
        },
        tooltip: {
          valueSuffix: '',
        },
        plotOptions: {
          column: {
            pointPadding: 0.2,
            borderWidth: 0,
          },
        },
        series: [
          {
            name: 'PE',
            data: allPE,
          },
          {
            name: 'CE',
            data: allCE,
          },
        ],
      };
    });
  }
}
