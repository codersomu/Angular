import { Injectable } from '@angular/core';
import holding from 'C:/workspace/datas/holdings.json';
//import company from 'C:/workspace/datas/allcompanys.json';
import current from 'C:/workspace/datas/total-trade.json';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  company: any = [];
  constructor(private http: HttpClient) {
    // fetch('http://localhost:3000/company/getallcompany')
    //   .then((response) => {
    //     return response.json();
    //   })
    //   .then((data) => {
    //     // Work with JSON data here
    //     console.log(data);
    //     this.company = data;
    //   })
    //   .catch((err) => {
    //     // Do something for an error here
    //   });
  }

  getHoldings() {
    return holding;
  }
  getMain() {
    return this.http.get('http://localhost:3000/company/getallcompany');
  }

  allHoldingStocks() {
    let stocks = holding.map((item) => item.symbol);
    return [...new Set(stocks)].sort();
  }

  getCompanyInfoByName(symbol) {
    return this.company.filter((item) => item.script == symbol)[0];
  }

  getFoDetails(stockname) {
    return this.http.get(
      'http://localhost:3000/fo/getdetails?stockname=RELIANCE&date=2025-02-19'
    );
  }
}
