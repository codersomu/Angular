import { Routes } from '@angular/router';
import { HoldingComponent } from './comparison/holding/holding.component';
import { FundamentalComponent } from './fundamental/fundamental.component';
import { BreakdownComponent } from './portfolio/breakdown/breakdown.component';

import { FoComponent } from './fo/fo.component';
export const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./portfolio/portfolio.module').then((m) => m.PortfolioModule),
    pathMatch: 'full',
  },

  {
    path: 'breakdown',
    component: BreakdownComponent,
    pathMatch: 'full',
  },

  {
    path: 'listing-all',
    loadChildren: () =>
      import('./intraday/intraday.module').then((m) => m.IntradayModule),
    pathMatch: 'full',
  },

  {
    path: 'comparison',
    loadChildren: () =>
      import('./comparison/comparison.module').then((m) => m.ComparisonModule),
    pathMatch: 'full',
  },
  {
    path: 'trades',
    loadChildren: () =>
      import('./trades/trades-routing.module').then(
        (m) => m.TradesRoutingModule
      ),
    pathMatch: 'full',
  },
  {
    path: 'holding',
    component: HoldingComponent,
    pathMatch: 'full',
  },

  {
    path: 'funda',
    component: FundamentalComponent,
    pathMatch: 'full',
  },
  {
    path: 'fo',
    component: FoComponent,
    pathMatch: 'full',
  },
];
