export const environment = {
  holdings: 'C:/workspace/datas/holdings.json',
};
